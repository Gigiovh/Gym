const audio= new audio();
audio.src="./imagens/videoplayblack.mp3"